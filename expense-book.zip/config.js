// Paste the "Web app URL" you get after deploying Code.gs (Apps Script) between the quotes.
// It looks like: https://script.google.com/macros/s/AKfycb.../exec
window.EXPENSE_CONFIG = {
  API_URL: ''
};
